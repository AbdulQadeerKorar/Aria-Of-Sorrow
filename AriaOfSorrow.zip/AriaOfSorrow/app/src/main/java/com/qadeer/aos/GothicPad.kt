package com.qadeer.aos

import android.content.Context
import android.graphics.*
import android.view.HapticFeedbackConstants
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import kotlin.math.hypot
import kotlin.math.min

/** Gothic-styled multitouch GBA controller. Portrait: pad under the screen. Landscape: translucent overlay. */
class GothicPad(ctx: Context) : View(ctx) {

    fun interface KeyListener { fun onKey(keyCode: Int, down: Boolean) }

    var listener: KeyListener? = null
    var swapAB = false

    private val rects = LinkedHashMap<String, RectF>()
    private val circles = setOf("A", "B")
    private val dpadC = PointF()
    private var dpadR = 0f
    private var gameH = 0f
    private val held = HashSet<String>()

    private val gold = Color.parseColor("#C9A227")
    private val crimson = Color.parseColor("#8B1A2B")
    private val hot = Color.parseColor("#E03550")
    private val dark = Color.parseColor("#1A0F26")

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD)
        textAlign = Paint.Align.CENTER
        color = gold
    }

    private fun keyFor(id: String): Int = when (id) {
        "A" -> if (swapAB) KeyEvent.KEYCODE_BUTTON_B else KeyEvent.KEYCODE_BUTTON_A
        "B" -> if (swapAB) KeyEvent.KEYCODE_BUTTON_A else KeyEvent.KEYCODE_BUTTON_B
        "L" -> KeyEvent.KEYCODE_BUTTON_L1
        "R" -> KeyEvent.KEYCODE_BUTTON_R1
        "START" -> KeyEvent.KEYCODE_BUTTON_START
        "SELECT" -> KeyEvent.KEYCODE_BUTTON_SELECT
        "UP" -> KeyEvent.KEYCODE_DPAD_UP
        "DOWN" -> KeyEvent.KEYCODE_DPAD_DOWN
        "LEFT" -> KeyEvent.KEYCODE_DPAD_LEFT
        else -> KeyEvent.KEYCODE_DPAD_RIGHT
    }

    private fun circle(id: String, cx: Float, cy: Float, r: Float) { rects[id] = RectF(cx - r, cy - r, cx + r, cy + r) }
    private fun box(id: String, l: Float, t: Float, r: Float, b: Float) { rects[id] = RectF(l, t, r, b) }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        rects.clear()
        val W = w.toFloat(); val H = h.toFloat()
        if (H > W) {
            gameH = W * 2f / 3f
            val ch = H - gameH; val top = gameH
            dpadR = min(W * 0.21f, ch * 0.27f)
            dpadC.set(W * 0.27f, top + ch * 0.56f)
            val br = dpadR * 0.52f
            circle("B", W * 0.66f, top + ch * 0.68f, br)
            circle("A", W * 0.86f, top + ch * 0.48f, br)
            box("L", W * 0.04f, top + ch * 0.03f, W * 0.32f, top + ch * 0.15f)
            box("R", W * 0.68f, top + ch * 0.03f, W * 0.96f, top + ch * 0.15f)
            val y = H - ch * 0.13f
            box("SELECT", W * 0.30f, y, W * 0.48f, y + ch * 0.075f)
            box("START", W * 0.52f, y, W * 0.70f, y + ch * 0.075f)
        } else {
            gameH = 0f
            dpadR = H * 0.19f
            dpadC.set(W * 0.13f, H * 0.64f)
            val br = dpadR * 0.5f
            circle("B", W * 0.80f, H * 0.74f, br)
            circle("A", W * 0.91f, H * 0.52f, br)
            box("L", W * 0.02f, H * 0.05f, W * 0.16f, H * 0.17f)
            box("R", W * 0.84f, H * 0.05f, W * 0.98f, H * 0.17f)
            box("SELECT", W * 0.36f, H * 0.89f, W * 0.47f, H * 0.96f)
            box("START", W * 0.53f, H * 0.89f, W * 0.64f, H * 0.96f)
        }
    }

    override fun onDraw(c: Canvas) {
        val a = if (gameH > 0f) 255 else 150
        if (gameH > 0f) {
            p.style = Paint.Style.FILL
            p.shader = LinearGradient(0f, gameH, 0f, height.toFloat(),
                Color.parseColor("#1C0E26"), Color.parseColor("#05030A"), Shader.TileMode.CLAMP)
            c.drawRect(0f, gameH, width.toFloat(), height.toFloat(), p)
            p.shader = null
            p.color = gold; p.strokeWidth = 3f
            c.drawLine(0f, gameH, width.toFloat(), gameH, p)
            // little ornaments on the divider
            for (i in 1..3) {
                val x = width * i / 4f
                val d = Path().apply { moveTo(x, gameH - 9f); lineTo(x + 9f, gameH); lineTo(x, gameH + 9f); lineTo(x - 9f, gameH); close() }
                p.color = crimson; p.style = Paint.Style.FILL; c.drawPath(d, p)
            }
        }
        drawDpad(c, a)
        for ((id, r) in rects) {
            val on = id in held
            val label = when (id) { "START" -> "START"; "SELECT" -> "SELECT"; else -> id }
            if (id in circles) {
                val cx = r.centerX(); val cy = r.centerY(); val rad = r.width() / 2f
                p.style = Paint.Style.FILL
                p.color = if (on) withA(hot, a) else withA(dark, a)
                c.drawCircle(cx, cy, rad, p)
                p.style = Paint.Style.STROKE; p.strokeWidth = rad * 0.12f
                p.color = withA(crimson, a); c.drawCircle(cx, cy, rad, p)
                p.strokeWidth = 2.5f; p.color = withA(gold, a); c.drawCircle(cx, cy, rad * 0.82f, p)
                txt.textSize = rad * 0.9f; txt.color = withA(gold, a)
                c.drawText(label, cx, cy + txt.textSize * 0.33f, txt)
            } else {
                val rad = r.height() / 2f
                p.style = Paint.Style.FILL
                p.color = if (on) withA(hot, a) else withA(dark, a)
                c.drawRoundRect(r, rad, rad, p)
                p.style = Paint.Style.STROKE; p.strokeWidth = 4f; p.color = withA(crimson, a)
                c.drawRoundRect(r, rad, rad, p)
                p.strokeWidth = 2f; p.color = withA(gold, a)
                c.drawRoundRect(RectF(r.left + 6, r.top + 6, r.right - 6, r.bottom - 6), rad, rad, p)
                txt.textSize = r.height() * 0.42f; txt.color = withA(gold, a)
                c.drawText(label, r.centerX(), r.centerY() + txt.textSize * 0.35f, txt)
            }
        }
    }

    private fun drawDpad(c: Canvas, a: Int) {
        val cx = dpadC.x; val cy = dpadC.y; val r = dpadR
        val arm = r * 0.32f
        val cross = Path().apply {
            addRoundRect(RectF(cx - arm, cy - r, cx + arm, cy + r), arm * 0.5f, arm * 0.5f, Path.Direction.CW)
            addRoundRect(RectF(cx - r, cy - arm, cx + r, cy + arm), arm * 0.5f, arm * 0.5f, Path.Direction.CW)
        }
        p.style = Paint.Style.FILL; p.color = withA(dark, a); c.drawPath(cross, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = 4f; p.color = withA(crimson, a); c.drawPath(cross, p)
        val tri = r * 0.17f; val off = r * 0.68f
        fun arrow(id: String, dx: Float, dy: Float) {
            val x = cx + dx * off; val y = cy + dy * off
            val path = Path()
            if (dx == 0f) {
                path.moveTo(x, y + dy * tri * 0.0f - dy * tri); path.lineTo(x - tri, y + dy * tri); path.lineTo(x + tri, y + dy * tri)
            } else {
                path.moveTo(x - dx * tri, y); path.lineTo(x + dx * tri, y - tri); path.lineTo(x + dx * tri, y + tri)
            }
            path.close()
            p.style = Paint.Style.FILL; p.color = withA(if (id in held) hot else gold, a); c.drawPath(path, p)
        }
        arrow("UP", 0f, -1f); arrow("DOWN", 0f, 1f); arrow("LEFT", -1f, 0f); arrow("RIGHT", 1f, 0f)
        p.style = Paint.Style.FILL; p.color = withA(crimson, a); c.drawCircle(cx, cy, arm * 0.45f, p)
    }

    private fun withA(color: Int, a: Int) = Color.argb(a, Color.red(color), Color.green(color), Color.blue(color))

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val now = HashSet<String>()
        val ending = e.actionMasked == MotionEvent.ACTION_UP || e.actionMasked == MotionEvent.ACTION_CANCEL
        if (!ending) {
            val slop = dpadR * 0.12f
            for (i in 0 until e.pointerCount) {
                if (e.actionMasked == MotionEvent.ACTION_POINTER_UP && i == e.actionIndex) continue
                val x = e.getX(i); val y = e.getY(i)
                val dx = x - dpadC.x; val dy = y - dpadC.y
                val dist = hypot(dx, dy)
                if (dist < dpadR * 1.5f && dist > dpadR * 0.15f) {
                    val t = dist * 0.38f
                    if (dx < -t) now += "LEFT"; if (dx > t) now += "RIGHT"
                    if (dy < -t) now += "UP"; if (dy > t) now += "DOWN"
                }
                for ((id, r) in rects) {
                    if (x >= r.left - slop && x <= r.right + slop && y >= r.top - slop && y <= r.bottom + slop) now += id
                }
            }
        }
        for (id in now) if (id !in held) {
            listener?.onKey(keyFor(id), true)
            performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
        }
        for (id in held) if (id !in now) listener?.onKey(keyFor(id), false)
        held.clear(); held.addAll(now)
        invalidate()
        return true
    }
}
