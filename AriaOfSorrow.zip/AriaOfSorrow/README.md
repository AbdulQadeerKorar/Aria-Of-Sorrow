# Aria of Sorrow – Gothic Touch Player

1. Create a new GitHub repo, upload everything in this folder (keep `.github/` intact).
2. Repo -> Actions -> "Build APK" -> Run workflow (it also runs on every push).
3. When green, open the run -> Artifacts -> download `AriaOfSorrow-apk` -> unzip -> install `app-debug.apk`.
4. Open the app, tap the screen, pick your own legally-dumped .gba file. It remembers it next time.

Menu (top-centre ☰): save/load state, swap A/B, change ROM. In-game saves (SRAM) auto-save every 30s and on exit.
If jump/attack feel reversed, use "Swap A/B".
Core: mGBA libretro (MPL-2.0), downloaded at build time. Frontend: LibretroDroid (GPL-3).
