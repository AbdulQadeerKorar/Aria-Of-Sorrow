package com.qadeer.aos

import android.app.AlertDialog
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.swordfish.libretrodroid.GLRetroView
import com.swordfish.libretrodroid.GLRetroViewData
import java.io.File

class MainActivity : ComponentActivity() {

    private lateinit var root: FrameLayout
    private lateinit var pad: GothicPad
    private lateinit var splash: TextView
    private lateinit var prefs: SharedPreferences
    private var retro: GLRetroView? = null
    private var romKey = ""
    private val handler = Handler(Looper.getMainLooper())
    private val autosave = object : Runnable {
        override fun run() { saveSram(); handler.postDelayed(this, 30_000) }
    }

    private val picker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            val changing = retro != null
            if (changing) saveSram()
            prefs.edit().putString("rom", uri.toString()).apply()
            if (changing) recreate() else startGame(uri)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("aos", MODE_PRIVATE)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        root = FrameLayout(this).apply { setBackgroundColor(Color.parseColor("#05060A")) }

        pad = GothicPad(this).apply {
            swapAB = prefs.getBoolean("swap", false)
            listener = GothicPad.KeyListener { k, down ->
                retro?.sendKeyEvent(if (down) KeyEvent.ACTION_DOWN else KeyEvent.ACTION_UP, k)
            }
        }
        root.addView(pad, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))

        splash = TextView(this).apply {
            text = "◆  ARIA OF SORROW  ◆\n\nTap to choose your .gba ROM"
            gravity = Gravity.CENTER
            setTextColor(Color.parseColor("#E6EAEE"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f); letterSpacing = 0.15f
            typeface = Typeface.create(Typeface.SERIF, Typeface.NORMAL)
            setOnClickListener { picker.launch(arrayOf("*/*")) }
        }
        root.addView(splash, FrameLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT, Gravity.CENTER))

        val menu = TextView(this).apply {
            text = "☰"
            setTextColor(Color.parseColor("#E6EAEE"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 24f)
            setPadding(dp(16), dp(6), dp(16), dp(6))
            alpha = 0.6f
            setOnClickListener { showMenu() }
        }
        root.addView(menu, FrameLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply { topMargin = dp(10) })

        setContentView(root)
        root.addOnLayoutChangeListener { _, l, t, r, b, _, _, _, _ -> layoutGame(r - l, b - t) }

        prefs.getString("rom", null)?.let { startGame(Uri.parse(it)) }
    }

    private fun layoutGame(w: Int, h: Int) {
        val v = retro ?: return
        val lp = v.layoutParams as FrameLayout.LayoutParams
        val wantH = if (h > w) w * 2 / 3 else MATCH_PARENT
        if (lp.height != wantH || lp.width != MATCH_PARENT) {
            lp.width = MATCH_PARENT; lp.height = wantH; lp.gravity = Gravity.TOP
            v.post { v.layoutParams = lp }
        }
    }

    private fun startGame(uri: Uri) {
        try {
            val bytes = contentResolver.openInputStream(uri)!!.use { it.readBytes() }
            romKey = uri.toString().hashCode().toString()
            val sram = File(filesDir, "sram_$romKey.bin")
            val data = GLRetroViewData(this).apply {
                coreFilePath = "libmgba_libretro_android.so"
                gameFileBytes = bytes
                systemDirectory = filesDir.absolutePath
                savesDirectory = File(filesDir, "saves").apply { mkdirs() }.absolutePath
                if (sram.exists()) saveRAMState = sram.readBytes()
                preferLowLatencyAudio = true
            }
            val v = GLRetroView(this, data)
            lifecycle.addObserver(v)
            retro = v
            root.addView(v, 0, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT, Gravity.TOP))
            splash.visibility = View.GONE
            layoutGame(root.width, root.height)
            handler.postDelayed(autosave, 30_000)
        } catch (e: Exception) {
            Toast.makeText(this, "Couldn't open ROM: ${e.message}", Toast.LENGTH_LONG).show()
            prefs.edit().remove("rom").apply()
            splash.visibility = View.VISIBLE
        }
    }

    private fun saveSram() {
        val r = retro ?: return
        try { File(filesDir, "sram_$romKey.bin").writeBytes(r.serializeSRAM()) } catch (_: Exception) {}
    }

    private fun showMenu() {
        val swapLabel = "🔁 Swap jump/attack buttons (now: ${if (pad.swapAB) "swapped" else "default"})"
        AlertDialog.Builder(this)
            .setTitle("Menu")
            .setItems(arrayOf("💾 Save state", "📂 Load state", swapLabel, "🎮 Change ROM")) { _, i ->
                when (i) {
                    0 -> retro?.let {
                        File(filesDir, "state_$romKey.bin").writeBytes(it.serializeState())
                        Toast.makeText(this, "State saved", Toast.LENGTH_SHORT).show()
                    }
                    1 -> retro?.let {
                        val f = File(filesDir, "state_$romKey.bin")
                        if (f.exists()) { it.unserializeState(f.readBytes()); Toast.makeText(this, "State loaded", Toast.LENGTH_SHORT).show() }
                        else Toast.makeText(this, "No saved state yet", Toast.LENGTH_SHORT).show()
                    }
                    2 -> { pad.swapAB = !pad.swapAB; prefs.edit().putBoolean("swap", pad.swapAB).apply() }
                    3 -> picker.launch(arrayOf("*/*"))
                }
            }.show()
    }

    override fun onResume() { super.onResume(); if (retro != null) { handler.removeCallbacks(autosave); handler.postDelayed(autosave, 30_000) } }
    override fun onPause() { saveSram(); handler.removeCallbacks(autosave); super.onPause() }
    override fun onStop() { saveSram(); super.onStop() }
}
