package com.qadeer.aos

import android.content.Context
import android.graphics.*
import android.view.HapticFeedbackConstants
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

/**
 * Stylized touch pad. No letters anywhere: every control is a drawn glyph.
 *  jump  = ascending wing chevrons      attack = blade
 *  L     = crescent moon                R      = soul flame
 *  start = pointer                      select = twin bars
 * D-pad is a four-petal ornate compass with a central orb.
 * Portrait: pad under the screen. Landscape: translucent overlay.
 */
class GothicPad(ctx: Context) : View(ctx) {

    fun interface KeyListener { fun onKey(keyCode: Int, down: Boolean) }

    var listener: KeyListener? = null
    var swapAB = false

    private val rects = LinkedHashMap<String, RectF>()
    private val circles = setOf("A", "B")
    private val hexes = setOf("START", "SELECT")
    private val dpadC = PointF()
    private var dpadR = 0f
    private var gameH = 0f
    private val held = HashSet<String>()
    private var ash = FloatArray(0)

    private val bone = Color.parseColor("#E6EAEE")
    private val ink = Color.parseColor("#07090D")
    private val slate = Color.parseColor("#1A1F29")

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    private fun keyFor(id: String): Int = when (id) {
        "A" -> if (swapAB) KeyEvent.KEYCODE_BUTTON_B else KeyEvent.KEYCODE_BUTTON_A
        "B" -> if (swapAB) KeyEvent.KEYCODE_BUTTON_A else KeyEvent.KEYCODE_BUTTON_B
        "L" -> KeyEvent.KEYCODE_BUTTON_L1
        "R" -> KeyEvent.KEYCODE_BUTTON_R1
        "START" -> KeyEvent.KEYCODE_BUTTON_START
        "SELECT" -> KeyEvent.KEYCODE_BUTTON_SELECT
        "UP" -> KeyEvent.KEYCODE_DPAD_UP
        "DOWN" -> KeyEvent.KEYCODE_DPAD_DOWN
        "LEFT" -> KeyEvent.KEYCODE_DPAD_LEFT
        else -> KeyEvent.KEYCODE_DPAD_RIGHT
    }

    /** glyph follows the action, so "Swap" in the menu also swaps the symbols */
    private fun glyphFor(id: String): String = when (id) {
        "A", "B" -> if (keyFor(id) == KeyEvent.KEYCODE_BUTTON_A) "jump" else "attack"
        "L" -> "moon"
        "R" -> "soul"
        "START" -> "start"
        else -> "select"
    }

    private fun circle(id: String, cx: Float, cy: Float, r: Float) { rects[id] = RectF(cx - r, cy - r, cx + r, cy + r) }
    private fun box(id: String, l: Float, t: Float, r: Float, b: Float) { rects[id] = RectF(l, t, r, b) }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        rects.clear()
        val W = w.toFloat(); val H = h.toFloat()
        if (H > W) {
            gameH = W * 2f / 3f
            val ch = H - gameH; val top = gameH
            dpadR = min(W * 0.23f, ch * 0.29f)
            dpadC.set(W * 0.27f, top + ch * 0.55f)
            val br = dpadR * 0.50f
            circle("B", W * 0.67f, top + ch * 0.68f, br)
            circle("A", W * 0.86f, top + ch * 0.46f, br)
            box("L", W * 0.05f, top + ch * 0.03f, W * 0.33f, top + ch * 0.14f)
            box("R", W * 0.67f, top + ch * 0.03f, W * 0.95f, top + ch * 0.14f)
            val y = H - ch * 0.12f
            box("SELECT", W * 0.28f, y, W * 0.48f, y + ch * 0.075f)
            box("START", W * 0.52f, y, W * 0.72f, y + ch * 0.075f)
            val rnd = Random(7)
            ash = FloatArray(36 * 3)
            for (i in 0 until 36) {
                ash[i * 3] = rnd.nextFloat() * W
                ash[i * 3 + 1] = gameH + 14f + rnd.nextFloat() * (H - gameH - 14f)
                ash[i * 3 + 2] = 0.8f + rnd.nextFloat() * 1.8f
            }
        } else {
            gameH = 0f; ash = FloatArray(0)
            dpadR = H * 0.20f
            dpadC.set(W * 0.13f, H * 0.64f)
            val br = dpadR * 0.48f
            circle("B", W * 0.80f, H * 0.74f, br)
            circle("A", W * 0.91f, H * 0.51f, br)
            box("L", W * 0.02f, H * 0.05f, W * 0.16f, H * 0.16f)
            box("R", W * 0.84f, H * 0.05f, W * 0.98f, H * 0.16f)
            box("SELECT", W * 0.35f, H * 0.89f, W * 0.48f, H * 0.96f)
            box("START", W * 0.52f, H * 0.89f, W * 0.65f, H * 0.96f)
        }
    }

    private fun col(c: Int, a: Int) = Color.argb(a.coerceIn(0, 255), Color.red(c), Color.green(c), Color.blue(c))

    private fun diamond(c: Canvas, x: Float, y: Float, s: Float, fill: Boolean, color: Int, width: Float = 1.5f) {
        val path = Path().apply { moveTo(x, y - s); lineTo(x + s, y); lineTo(x, y + s); lineTo(x - s, y); close() }
        p.shader = null; p.color = color
        p.style = if (fill) Paint.Style.FILL else Paint.Style.STROKE; p.strokeWidth = width
        c.drawPath(path, p)
    }

    override fun onDraw(c: Canvas) {
        val a = if (gameH > 0f) 255 else 175
        val W = width.toFloat(); val H = height.toFloat()
        if (gameH > 0f) drawBackdrop(c, W, H)
        drawDpad(c, a)
        for ((id, r) in rects) {
            val on = id in held
            when (id) {
                in circles -> drawRound(c, id, r, a, on)
                in hexes -> drawHex(c, id, r, a, on)
                else -> drawShoulder(c, id, r, a, on)
            }
        }
    }

    private fun drawBackdrop(c: Canvas, W: Float, H: Float) {
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(0f, gameH, 0f, H, Color.parseColor("#0B0E14"), Color.BLACK, Shader.TileMode.CLAMP)
        c.drawRect(0f, gameH, W, H, p); p.shader = null
        var i = 0
        while (i < ash.size) {
            p.color = col(bone, (28 + ash[i + 2] * 28).toInt()); p.style = Paint.Style.FILL
            c.drawCircle(ash[i], ash[i + 1], ash[i + 2], p); i += 3
        }
        p.style = Paint.Style.STROKE; p.strokeWidth = 2f
        p.shader = LinearGradient(0f, 0f, W, 0f,
            intArrayOf(col(bone, 0), col(bone, 200), col(bone, 0)), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)
        c.drawLine(0f, gameH, W, gameH, p); p.shader = null
        diamond(c, W / 2, gameH, 9f, false, col(bone, 230), 2f)
        diamond(c, W / 2, gameH, 4f, true, col(bone, 230))
        diamond(c, W / 2 - 34f, gameH, 3.5f, true, col(bone, 160))
        diamond(c, W / 2 + 34f, gameH, 3.5f, true, col(bone, 160))
    }

    // ---------------------------------------------------------------- glyphs
    /** draws a glyph in unit space (about -0.55..0.55) scaled by s around (cx,cy) */
    private fun glyph(c: Canvas, kind: String, cx: Float, cy: Float, s: Float, color: Int) {
        c.save(); c.translate(cx, cy); c.scale(s, s)
        p.shader = null; p.color = color
        p.strokeCap = Paint.Cap.ROUND; p.strokeJoin = Paint.Join.ROUND
        when (kind) {
            "jump" -> {
                p.style = Paint.Style.STROKE; p.strokeWidth = 0.1f
                c.drawPath(Path().apply { moveTo(-0.4f, 0.02f); lineTo(0f, -0.32f); lineTo(0.4f, 0.02f) }, p)
                c.drawPath(Path().apply { moveTo(-0.4f, 0.38f); lineTo(0f, 0.04f); lineTo(0.4f, 0.38f) }, p)
                p.style = Paint.Style.FILL
                c.drawPath(Path().apply { moveTo(0f, -0.62f); lineTo(0.08f, -0.52f); lineTo(0f, -0.42f); lineTo(-0.08f, -0.52f); close() }, p)
            }
            "attack" -> {
                p.style = Paint.Style.FILL
                // blade (tip up-right)
                c.drawPath(Path().apply { moveTo(0.46f, -0.46f); lineTo(0.07f, 0.0f); lineTo(0.0f, -0.07f); close() }, p)
                p.style = Paint.Style.STROKE; p.strokeWidth = 0.09f
                c.drawLine(0.22f, 0.22f, -0.2f, -0.2f, p)          // cross-guard
                c.drawLine(0.0f, 0.0f, -0.36f, 0.36f, p)           // grip
                p.style = Paint.Style.FILL
                c.drawPath(Path().apply { moveTo(-0.42f, 0.42f); lineTo(-0.34f, 0.5f); lineTo(-0.5f, 0.5f); close() }, p)
            }
            "moon" -> {
                val outer = Path().apply { addCircle(0f, 0f, 0.5f, Path.Direction.CW) }
                val cut = Path().apply { addCircle(0.22f, -0.08f, 0.44f, Path.Direction.CW) }
                outer.op(cut, Path.Op.DIFFERENCE)
                p.style = Paint.Style.FILL; c.drawPath(outer, p)
                diamond(c, 0.3f, 0.28f, 0.07f, true, color)
            }
            "soul" -> {
                val drop = Path().apply {
                    moveTo(0f, -0.52f)
                    cubicTo(0.12f, -0.25f, 0.4f, 0.0f, 0.4f, 0.22f)
                    cubicTo(0.4f, 0.38f, 0.22f, 0.48f, 0f, 0.48f)
                    cubicTo(-0.22f, 0.48f, -0.4f, 0.38f, -0.4f, 0.22f)
                    cubicTo(-0.4f, 0.0f, -0.12f, -0.25f, 0f, -0.52f)
                    close()
                }
                p.style = Paint.Style.STROKE; p.strokeWidth = 0.08f; c.drawPath(drop, p)
                p.style = Paint.Style.FILL
                c.drawPath(Path().apply {
                    moveTo(0f, -0.08f); cubicTo(0.06f, 0.06f, 0.16f, 0.14f, 0.16f, 0.24f)
                    cubicTo(0.16f, 0.32f, 0.08f, 0.36f, 0f, 0.36f)
                    cubicTo(-0.08f, 0.36f, -0.16f, 0.32f, -0.16f, 0.24f)
                    cubicTo(-0.16f, 0.14f, -0.06f, 0.06f, 0f, -0.08f); close()
                }, p)
            }
            "start" -> {
                p.style = Paint.Style.FILL
                c.drawPath(Path().apply { moveTo(-0.22f, -0.38f); lineTo(0.38f, 0f); lineTo(-0.22f, 0.38f); close() }, p)
            }
            else -> { // select
                p.style = Paint.Style.STROKE; p.strokeWidth = 0.14f
                c.drawLine(-0.4f, -0.17f, 0.4f, -0.17f, p)
                c.drawLine(-0.4f, 0.17f, 0.4f, 0.17f, p)
            }
        }
        p.strokeCap = Paint.Cap.BUTT; p.strokeJoin = Paint.Join.MITER
        c.restore()
    }

    // --------------------------------------------------------------- buttons
    private fun drawRound(c: Canvas, id: String, r: RectF, a: Int, on: Boolean) {
        val cx = r.centerX(); val cy = r.centerY(); val rad = r.width() / 2f
        if (on) {
            p.style = Paint.Style.FILL
            p.shader = RadialGradient(cx, cy, rad * 1.4f, col(bone, 95 * a / 255), col(bone, 0), Shader.TileMode.CLAMP)
            c.drawCircle(cx, cy, rad * 1.4f, p)
        }
        p.style = Paint.Style.FILL
        p.shader = if (on)
            RadialGradient(cx, cy, rad, col(bone, 85 * a / 255), col(bone, 28 * a / 255), Shader.TileMode.CLAMP)
        else
            RadialGradient(cx, cy, rad, col(ink, 200 * a / 255), col(slate, 215 * a / 255), Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, rad, p); p.shader = null
        p.style = Paint.Style.STROKE
        p.strokeWidth = 2.6f; p.color = col(bone, 235 * a / 255); c.drawCircle(cx, cy, rad, p)
        p.strokeWidth = 1.2f; p.color = col(bone, 110 * a / 255); c.drawCircle(cx, cy, rad * 0.82f, p)
        val s = rad * 0.075f
        for ((dx, dy) in listOf(0 to -1, 0 to 1, -1 to 0, 1 to 0))
            diamond(c, cx + dx * rad, cy + dy * rad, s, true, col(bone, 235 * a / 255))
        glyph(c, glyphFor(id), cx, cy, rad * 0.62f, col(bone, 245 * a / 255))
    }

    private fun drawShoulder(c: Canvas, id: String, r: RectF, a: Int, on: Boolean) {
        val rad = r.height() / 2f
        p.style = Paint.Style.FILL; p.shader = null
        p.color = if (on) col(bone, 80 * a / 255) else col(ink, 200 * a / 255)
        c.drawRoundRect(r, rad, rad, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = 2.4f; p.color = col(bone, 235 * a / 255)
        c.drawRoundRect(r, rad, rad, p)
        p.strokeWidth = 1.1f; p.color = col(bone, 100 * a / 255)
        c.drawRoundRect(RectF(r.left + 6, r.top + 6, r.right - 6, r.bottom - 6), rad, rad, p)
        diamond(c, r.left + rad * 0.55f, r.centerY(), rad * 0.2f, true, col(bone, 220 * a / 255))
        diamond(c, r.right - rad * 0.55f, r.centerY(), rad * 0.2f, true, col(bone, 220 * a / 255))
        glyph(c, glyphFor(id), r.centerX(), r.centerY(), r.height() * 0.36f, col(bone, 245 * a / 255))
    }

    private fun drawHex(c: Canvas, id: String, r: RectF, a: Int, on: Boolean) {
        val h = r.height(); val cy = r.centerY()
        val path = Path().apply {
            moveTo(r.left, cy); lineTo(r.left + h / 2, r.top); lineTo(r.right - h / 2, r.top)
            lineTo(r.right, cy); lineTo(r.right - h / 2, r.bottom); lineTo(r.left + h / 2, r.bottom); close()
        }
        p.style = Paint.Style.FILL; p.shader = null
        p.color = if (on) col(bone, 80 * a / 255) else col(ink, 200 * a / 255)
        c.drawPath(path, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = 2f; p.color = col(bone, 225 * a / 255)
        c.drawPath(path, p)
        glyph(c, glyphFor(id), r.centerX(), cy, h * 0.3f, col(bone, 240 * a / 255))
    }

    // ----------------------------------------------------------------- d-pad
    private fun drawDpad(c: Canvas, a: Int) {
        val cx = dpadC.x; val cy = dpadC.y; val r = dpadR
        // soft halo
        p.style = Paint.Style.FILL
        p.shader = RadialGradient(cx, cy, r * 1.25f, col(bone, 30 * a / 255), col(bone, 0), Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, r * 1.25f, p); p.shader = null
        // faint outer ring + diagonal diamonds
        p.style = Paint.Style.STROKE; p.strokeWidth = 1.2f; p.color = col(bone, 70 * a / 255)
        c.drawCircle(cx, cy, r * 1.08f, p)
        for (deg in intArrayOf(-135, -45, 45, 135)) {
            val t = Math.toRadians(deg.toDouble())
            diamond(c, cx + (r * 0.72f * cos(t)).toFloat(), cy + (r * 0.72f * sin(t)).toFloat(),
                r * 0.06f, true, col(bone, 150 * a / 255))
        }
        // four petals
        val w = r * 0.24f
        val petal = Path().apply {
            moveTo(cx, cy - r)
            lineTo(cx + w, cy - r * 0.52f)
            lineTo(cx + w * 0.62f, cy - r * 0.25f)
            lineTo(cx - w * 0.62f, cy - r * 0.25f)
            lineTo(cx - w, cy - r * 0.52f)
            close()
        }
        val dirs = listOf("UP" to 0f, "RIGHT" to 90f, "DOWN" to 180f, "LEFT" to 270f)
        for ((id, deg) in dirs) {
            val on = id in held
            c.save(); c.rotate(deg, cx, cy)
            p.style = Paint.Style.FILL
            p.shader = if (on)
                RadialGradient(cx, cy - r * 0.6f, r * 0.55f, col(bone, 190 * a / 255), col(bone, 70 * a / 255), Shader.TileMode.CLAMP)
            else
                LinearGradient(cx, cy - r, cx, cy - r * 0.25f, col(slate, 215 * a / 255), col(ink, 210 * a / 255), Shader.TileMode.CLAMP)
            c.drawPath(petal, p); p.shader = null
            p.style = Paint.Style.STROKE; p.strokeWidth = 2.4f; p.color = col(bone, 235 * a / 255)
            c.drawPath(petal, p)
            p.strokeWidth = 1.2f; p.color = col(if (on) ink else bone, (if (on) 200 else 110) * a / 255)
            c.drawLine(cx, cy - r * 0.86f, cx, cy - r * 0.4f, p)
            c.restore()
        }
        // central orb
        p.style = Paint.Style.FILL; p.color = col(ink, 245 * a / 255); c.drawCircle(cx, cy, r * 0.2f, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = 2.2f; p.color = col(bone, 235 * a / 255); c.drawCircle(cx, cy, r * 0.2f, p)
        p.strokeWidth = 1.1f; p.color = col(bone, 110 * a / 255); c.drawCircle(cx, cy, r * 0.13f, p)
        diamond(c, cx, cy, r * 0.065f, true, col(bone, 240 * a / 255))
    }

    // ----------------------------------------------------------------- touch
    override fun onTouchEvent(e: MotionEvent): Boolean {
        val now = HashSet<String>()
        val ending = e.actionMasked == MotionEvent.ACTION_UP || e.actionMasked == MotionEvent.ACTION_CANCEL
        if (!ending) {
            val slop = dpadR * 0.12f
            for (i in 0 until e.pointerCount) {
                if (e.actionMasked == MotionEvent.ACTION_POINTER_UP && i == e.actionIndex) continue
                val x = e.getX(i); val y = e.getY(i)
                val dx = x - dpadC.x; val dy = y - dpadC.y
                val dist = hypot(dx, dy)
                if (dist < dpadR * 1.5f && dist > dpadR * 0.15f) {
                    val t = dist * 0.38f
                    if (dx < -t) now += "LEFT"; if (dx > t) now += "RIGHT"
                    if (dy < -t) now += "UP"; if (dy > t) now += "DOWN"
                }
                for ((id, r) in rects) {
                    if (x >= r.left - slop && x <= r.right + slop && y >= r.top - slop && y <= r.bottom + slop) now += id
                }
            }
        }
        for (id in now) if (id !in held) {
            listener?.onKey(keyFor(id), true)
            performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
        }
        for (id in held) if (id !in now) listener?.onKey(keyFor(id), false)
        held.clear(); held.addAll(now)
        invalidate()
        return true
    }
}
