# Aria of Sorrow – Stylized Touch Player (complete project)

Build: upload this zip to a GitHub repo root + the workflow file, run "Build APK", download the artifact.
Controls are all drawn glyphs (no letters): wing-chevrons = jump, blade = attack,
crescent = L, soul-flame = R, pointer = Start, twin bars = Select, petal compass = D-pad.
Menu (top centre): save/load state, swap jump/attack, change ROM.
Core: mGBA libretro (downloaded at build time). Frontend: LibretroDroid.
